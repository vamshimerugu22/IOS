//
//  ResultViewController.swift
//  currencyApp
//
//  Created by Kalla,Muralidhar Reddy on 4/7/22.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var EnteredNameOutlet: UILabel!
    
    @IBOutlet weak var EnteredINROutlet: UILabel!
    
    @IBOutlet weak var EnteredUSDOutlet: UILabel!
    
    @IBOutlet weak var ResultLabelOutlet: UILabel!
    
    var name = ""
    var indianRuppee = ""
    var USdollar = ""
    var INRToUSD = ""
    var USDToINR = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        EnteredNameOutlet.text = EnteredNameOutlet.text! + name
        EnteredINROutlet.text = EnteredINROutlet.text! + indianRuppee
        EnteredUSDOutlet.text = EnteredUSDOutlet.text! + USdollar
        ResultLabelOutlet.text = "Hello \(name)" + "\nAmount Rs.\(indianRuppee) in USD IS $\(INRToUSD)" + "\nAmount $\(USdollar) in INR is RS.\(USDToINR)"
    }
    

   

}
