//
//  ViewController.swift
//  currencyApp
//
//  Created by Kalla,Muralidhar Reddy on 4/7/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var NameOutlet: UITextField!

    @IBOutlet weak var INROutlet: UITextField!
    
    @IBOutlet weak var USdOutlet: UITextField!
    
    var convertToUS = 0.0
    var convertToINR = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func convertButtonPressed(_ sender: UIButton) {
        
        var name = NameOutlet.text!
        var ruppee = Double(INROutlet.text!)
        var dollar = Double(USdOutlet.text!)
        
        let x = Double(ruppee!/74.64)
        let y = Double(dollar! * 74.64)
        
        convertToUS = Double(round(100*x)/100)
        convertToINR = Double(round(100*y)/100)
        
        
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition = segue.identifier
        
        
        if transition == "resultSegue" {
            
            var destination = segue.destination as! ResultViewController
            
            destination.name = NameOutlet.text!
            destination.indianRuppee = INROutlet.text!
            destination.USdollar = USdOutlet.text!
            destination.INRToUSD = String(convertToUS)
            destination.USDToINR = String(convertToINR)
            
            
            
        }
    }

}

