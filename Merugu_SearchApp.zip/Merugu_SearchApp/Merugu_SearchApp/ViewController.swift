//
//  ViewController.swift
//  Merugu_SearchApp
//
//  Created by Merugu,Vamshi on 3/1/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var SearchTextfield: UITextField!
    
    @IBOutlet weak var resultimage: UIImageView!
    
    @IBOutlet weak var SearchButton: UIButton!
    
    @IBOutlet weak var TopicInfoText: UITextView!
    
    
    @IBOutlet weak var PreviousButton: UIButton!
    
    
   
    @IBOutlet weak var NextButton: UIButton!
    
    
    @IBOutlet weak var ResetButton: UIButton!
    
    
    
    
    
    var imageNum = 0;
    var topic: Int = -1
    var count : Int = -1
    var listOfArrays = [["Dinosaur","Elephant","Kingkong","Lion","Tiger"],["Bajajavenger","Honda gold wing","KTMDuke","Pulsar220","R15"],["Maheshbabu","NTR","Prabhas","sarvanand","Surya"]]

    var Animals_keywords = ["animal"," rodent"," murine","macaca"]
    var Bikes_keywords = ["Bike","Motorbike","vehicle","chopper"]

   var Actors_keywords = ["Actor","Superstar","naturalstar","megapowerstar"]
    var topics_discription = [["They first appeared during the Triassic period, between 243 and 233.23 million years ago, although the exact origin and timing of the evolution of dinosaurs is the subject of active research ,They became the dominant terrestrial vertebrates after the Triassic–Jurassic extinction event 201.3 million years ago; their dominance continued throughout the Jurassic and Cretaceous periods.","Elephants are the largest land mammals on earth and have distinctly massive bodies, large ears, and long trunks. They use their trunks to pick up objects, trumpet warnings, greet other elephants, or suck up water for drinking or bathing, among other uses. Both male and female African elephants grow tusks and each individual can either be left- or right-tusked, and the one they use more is usually smaller because of wear and tear.","JIn his first appearance in King Kong (1933), Kong was a gigantic prehistoric ape. While gorilla-like in appearance, he had a vaguely humanoid look and at times walked upright in an anthropomorphic manner. Like most simians, Kong possesses semi-human intelligence and great physical strength.","The lion (Panthera leo) is a large cat of the genus Panthera native to Africa and India. It has a muscular, deep-chested body, short, rounded head, round ears, and a hairy tuft at the end of its tail. It is sexually dimorphic; adult male lions are larger than females and have a prominent mane. It is a social species, forming groups called prides. A lion's pride consists of a few adult males, related females, and cubs.","The tiger (Panthera tigris) is the largest living cat species and a member of the genus Panthera. It is most recognisable for its dark vertical stripes on orange fur with a white underside. An apex predator, it primarily preys on ungulates such as deer and wild boar."],["The Bajaj Avenger is a cruiser style motorcycle designed and manufactured by Bajaj Auto in India. It draws the styling and other design cues from the Kawasaki Eliminator which had an air-cooled, single-cylinder Kawasaki engine and was sold at a premium.","The Honda Gold Wing is a series of touring motorcycles manufactured by Honda. Gold Wings feature shaft drive and a flat engine. Introduced at the Cologne Motorcycle Show in October 1974,[4] the Gold Wing went on to become a popular model in North America, Western Europe and Australia, as well as Japan.","The KTM 690 Duke is the latest generation in KTM's line of midrange single-cylinder engine supermoto, or naked motorcycles that began with the 1994 609 cc (37.2 cu in) displacement Duke 620 or Duke I, followed by the 1998 625 cc (38.1 cu in) Duke 640 or Duke II, followed by the 654 cc (39.9 cu in) Duke III, and finally the 690 cc (42 cu in) Duke IV made since 2012. Both the Duke III and Duke IV are called the 690 Duke.","The Bajaj 220F is an interesting contradiction in terms. Mechanically it's old-school, with proven technology and impressive levels of build quality.","The Yamaha YZF-R15 is a single cylinder sport bike made by Yamaha Motor Company since 2008.[1] In September 2011, the second iteration, called v2.0, was released in India,[2] and in April 2014 it was released in Indonesia. "],["Ghattamaneni Mahesh Babu (born 9 August 1975) is an Indian actor, producer, media personality, and philanthropist who works mainly in Telugu cinema. He has appeared in more than 25 films, and won several accolades including, eight Nandi Awards, five Filmfare South Awards, four South Indian International Movie Awards, three CineMAA Awards, and one IIFA Utsavam Award.","Nandamuri Taraka Rama Rao (28 May 1923 – 18 January 1996),[1] popularly known as NTR, was an Indian actor, filmmaker and politician who served as Chief Minister of Andhra Pradesh for seven years over three terms. He starred in over 300 films, predominantly in Telugu cinema, and was referred to as Viswa Vikhyatha Nata Sarwa Bhouma (transl. World's famous emperor of acting).","Uppalapati Venkata Suryanarayana Prabhas Raju (born 23 October 1979), known mononymously as Prabhas, is an Indian actor who works predominantly in Telugu cinema. One of the highest-paid actors in Indian cinema,[4] Prabhas has featured in Forbes India's Celebrity 100 list three times since 2015 based on his income and popularity.","Sharwanand Myneni (born 6 March 1984) is an Indian actor who primarily works in Telugu films alongside a few Tamil films. He received SIIMA Award for Best Male Debut for his work in Engeyum Eppodhum (2012), and a Nandi Special Jury Award for Malli Malli Idi Rani Roju (2015).","Saravanan Sivakumar (born 23 July 1975), known by his stage name Suriya, is an Indian actor, producer, television presenter and a philanthropist. He is best known for his work in Tamil cinema,[3] where he is one of the highest paid actors.[4] Among his awards include three Tamil Nadu State Film Awards, four Filmfare Awards South, two Edison Awards, a Cinema Express Award,[5] a CineMAA Award and a Vijay Award."]]
    
    
    
    override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
    PreviousButton.isHidden = true
    NextButton.isHidden = true
    ResetButton.isHidden = true
        SearchButton.isEnabled = false
    resultimage.image = UIImage(named: "searchnot found")
    }
    
    
    @IBAction func textFieldAction(_ sender: UITextField) {
        SearchButton.isEnabled = true
    }
    
    
    @IBAction func SearchButtonAction(_ sender: UIButton) {
        
        if(Animals_keywords.contains(SearchTextfield.text!)){
        topic = 0
        imageNum = 0
        buttonsDisable()
        }
        else if(Bikes_keywords.contains(SearchTextfield.text!)){
        topic = 1
        imageNum = 0
        buttonsDisable()
        }
        else if(Actors_keywords.contains(SearchTextfield.text!)){
        topic = 2
        imageNum = 0;
        buttonsDisable()
        }
        else{
        topic = -1
        resultimage.image = UIImage(named: "searchnot found")
        TopicInfoText.text = "No matches found with the given Keywords."
        ResetButton.isHidden = true
        NextButton.isHidden = true
        PreviousButton.isHidden = true
        }

        if(topic != -1)
        {
        PreviousButton.isEnabled = false
        NextButton.isEnabled = true
        count = listOfArrays[topic].count
        resultimage.image = UIImage(named: listOfArrays[topic][0])
        TopicInfoText.text = topics_discription[topic][0]
        }

    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
        
        NextButton.isEnabled = true;
        imageNum -= 1
        resultimage.image = UIImage(named: listOfArrays[topic][imageNum])
        TopicInfoText.text = topics_discription[topic][imageNum]
        if(imageNum == 0){
        PreviousButton.isEnabled = false
        }
        
        
        
        
    }
    
    
    @IBAction func showNextImagesBtn(_ sender: UIButton) {
      
        PreviousButton.isEnabled = true
        imageNum += 1
        resultimage.image = UIImage(named: listOfArrays[topic][imageNum])
        TopicInfoText.text = topics_discription[topic][imageNum]
        if(imageNum == count-1){
        NextButton.isEnabled = false
        }
    }
    
    
    @IBAction func ResetButton(_ sender: UIButton) {
        
        
        NextButton.isHidden = true
        PreviousButton.isHidden = true
        ResetButton.isHidden = true
        SearchTextfield.text = ""
        TopicInfoText.text = ""
        resultimage.image = UIImage(named: "searchnot found")
        SearchButton.isEnabled = false
        


        }

        func buttonsDisable(){
        NextButton.isHidden = false
        PreviousButton.isHidden = false
        ResetButton.isHidden = false
        }

        }



    
    
    



