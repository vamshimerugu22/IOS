//
//  ResultViewController.swift
//  discount
//
//  Created by Merugu,Vamshi on 4/7/22.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var EnteredAmountOutlet: UILabel!
    
    @IBOutlet weak var EnteredDiscrateOutlet: UILabel!
    
    @IBOutlet weak var PriceAfterDiscOutlet: UILabel!
    
    var amount = " "
    var discountrate = " "
    var priceAfterDisc = " "
    

    override func viewDidLoad() {
        super.viewDidLoad()

        
    
    

    EnteredAmountOutlet.text = EnteredAmountOutlet.text!+amount
    EnteredDiscrateOutlet.text = EnteredDiscrateOutlet.text!+discountrate
    PriceAfterDiscOutlet.text = PriceAfterDiscOutlet.text!+priceAfterDisc
    
}
}
