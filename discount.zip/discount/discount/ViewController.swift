//
//  ViewController.swift
//  discount
//
//  Created by Merugu,Vamshi on 4/7/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var AmountOutlet: UITextField!
    
    @IBOutlet weak var DiscountOutlet: UITextField!
    
    
    var priceAfterDiscount = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    
    }
    @IBAction func ClacDiscountPressed(_ sender: UIButton) {
        
        
        var amount = Double(AmountOutlet.text!)
        print(amount!)
        var discountRate  = Double(DiscountOutlet.text!)
        print(discountRate!)
        
        priceAfterDiscount = amount! -
        (amount!*discountRate!/100)
        print(priceAfterDiscount)
        
    
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition = segue.identifier
        if transition == "Resultsegue"{
            var destination = segue.destination as! ResultViewController
            destination.amount = AmountOutlet.text!
            destination.discountrate = DiscountOutlet.text!
            destination.priceAfterDisc = String(priceAfterDiscount)
            
        }
    }
}

